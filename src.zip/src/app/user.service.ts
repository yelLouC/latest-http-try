import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx';
import { map } from 'rxjs/operators';

@Injectable()
export class UserService {
  users=[];
  edit_values=[];
  active_id : number;

  constructor(private http: Http) { }

  saveData(f){
    if(this.users === null || this.users.length === 0){
      const users=[];
      users.push(f);
      this.http.put('https://first-try-http.firebaseio.com/user.json',users).subscribe();
    }
    else{
      this.users.push(f);
      console.log(this.users);
      this.http.put('https://first-try-http.firebaseio.com/user.json',this.users).subscribe();
    }
    
  
  }

  setData() {  
   return this.http.get('https://first-try-http.firebaseio.com/user.json')
    .pipe(map(
      (response : Response) => { 
        this.users= response.json();    
        //console.log('setuser ' + this.users);        
        return this.users;
        // const newData = [];
        // for (const user of data) {
        //   const uData = {
        //     age: user.age,
        //     email: user.email,
        //     name: user.name
        //   };
        //   newData.push(uData);
        // }
        // this.users = newData;
        // console.log('newdata ' + newData);
        // return this.users;
      }
    ));
  }

  getData(){
    return this.users;
    
  }

  //EDIT SECTION
  saveEdit(f){
    // console.log(f);
    // this.http.put('https://first-try-http.firebaseio.com/user/'+ this.active_id+'.json', f).subscribe();
    this.users[this.active_id] = f;
    this.http.put('https://first-try-http.firebaseio.com/user.json',this.users).subscribe();

  
  }

  setEdit(id :number){
   this.active_id= id;
  }

  getEdit(){
    return this.edit_values=this.users[this.active_id];   
  }

  //REMOVE SECTION
  setRemove(id: number){
    this.users.splice(id, 1); 
    
    this.http.put('https://first-try-http.firebaseio.com/user.json',this.users).subscribe();
  }

  
}
