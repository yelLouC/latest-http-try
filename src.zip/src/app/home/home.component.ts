import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Response } from '@angular/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  users=[];
  edit_values=[];

  active_id:number;

  flag= false;
  edit_mode= false;


  
  myform = new FormGroup({
    'name': new FormControl('', Validators.required),
    'age' : new FormControl('', Validators.required),
    'email' : new FormControl('', [Validators.required,Validators.email]),
  });

  
  constructor(private userService : UserService) {
    this.userService.setData().subscribe(
      (user) => {
        this.users = user;
      }
    );
    //this.users=this.userService.getData();
    // console.log('home ' + this.users);
    
  }


  ngOnInit() {
    
  }

  // FOR ADD
  onSubmit(){
    this.userService.saveData(this.myform.value);
    this.myform.reset();
  }
 
  // FOR EDIT
  onEdit(id){
    
    this.edit_mode = true;
    this.active_id = id;

    this.userService.setEdit(id);
    this.edit_values=this.userService.getEdit();

    console.log(this.edit_values);
    this.myform = new FormGroup({
      'name': new FormControl(this.edit_values['name'], Validators.required),
      'age' : new FormControl(this.edit_values['age'], Validators.required),
      'email' : new FormControl(this.edit_values['email'], [Validators.required,Validators.email]),
    });
    
  }

  onUpdate(){
    this.edit_mode = false;
    this.userService.saveEdit(this.myform.value);
    this.myform.reset();
  }

  

  onCancel(){
    this.myform.reset();
  }
   
  

  
  //FOR REMOVE
  onRemove(id){
    this.userService.setRemove(id);
    
  }

}
